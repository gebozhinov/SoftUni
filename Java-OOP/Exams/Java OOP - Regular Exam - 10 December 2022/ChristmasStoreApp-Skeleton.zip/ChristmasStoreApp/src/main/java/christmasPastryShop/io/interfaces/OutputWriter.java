package christmasPastryShop.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
