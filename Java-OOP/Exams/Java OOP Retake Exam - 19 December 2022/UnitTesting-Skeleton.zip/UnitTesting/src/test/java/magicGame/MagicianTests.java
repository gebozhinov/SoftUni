package magicGame;

public class MagicianTests {
    //TODO
}
