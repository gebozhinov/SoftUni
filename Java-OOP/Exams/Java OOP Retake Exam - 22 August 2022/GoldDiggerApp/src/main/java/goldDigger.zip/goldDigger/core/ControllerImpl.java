package goldDigger.core;

import goldDigger.models.discoverer.*;
import goldDigger.models.operation.Operation;
import goldDigger.models.operation.OperationImpl;
import goldDigger.models.spot.Spot;
import goldDigger.models.spot.SpotImpl;
import goldDigger.repositories.DiscovererRepository;
import goldDigger.repositories.Repository;
import goldDigger.repositories.SpotRepository;

import java.util.List;
import java.util.stream.Collectors;

import static goldDigger.common.ConstantMessages.*;
import static goldDigger.common.ExceptionMessages.*;

public class ControllerImpl implements Controller {


    private Repository<Discoverer> discovererRepository;
    private Repository<Spot> spotRepository;

    private int inspectedSpots = 0;

    public ControllerImpl() {
        this.discovererRepository = new DiscovererRepository();
        this.spotRepository = new SpotRepository();
    }


    @Override
    public String addDiscoverer(String kind, String discovererName) {
        Discoverer baseDiscoverer;
        switch (kind) {
            case "Anthropologist":
                baseDiscoverer = new Anthropologist(discovererName);
                break;
            case "Archaeologist":
                baseDiscoverer = new Archaeologist(discovererName);
                break;
            case "Geologist":
                baseDiscoverer = new Geologist(discovererName);
                break;
            default:
                throw new IllegalArgumentException(DISCOVERER_INVALID_KIND);
        }
        discovererRepository.add(baseDiscoverer);
        return String.format(DISCOVERER_ADDED, kind, discovererName);
    }

    @Override
    public String addSpot(String spotName, String... exhibits) {
        Spot spot = new SpotImpl(spotName);
        for (String exhibit : exhibits) {
            spot.getExhibits().add(exhibit);
        }
        spotRepository.add(spot);
        return String.format(SPOT_ADDED, spotName);
    }

    @Override
    public String excludeDiscoverer(String discovererName) {
        Discoverer discoverer = discovererRepository.byName(discovererName);
        StringBuilder sb = new StringBuilder();
        if (discoverer != null) {
            discovererRepository.remove(discoverer);
            sb.append(String.format(DISCOVERER_EXCLUDE, discovererName));
        } else {
            sb.append(String.format(DISCOVERER_DOES_NOT_EXIST, discovererName));
        }
        return sb.toString();
    }

    @Override
    public String inspectSpot(String spotName) {
        List<Discoverer> discoverers = discovererRepository.getCollection().stream()
                .filter(discoverer -> discoverer.getEnergy() > 45)
                .collect(Collectors.toList());

        if (discoverers.isEmpty()) {
            throw new IllegalArgumentException(SPOT_DISCOVERERS_DOES_NOT_EXISTS);
        }

        Spot spot = spotRepository.byName(spotName);
        Operation operation = new OperationImpl();
        operation.startOperation(spot, discoverers);

        long tiredDiscoverers = discoverers.stream()
                .filter(discoverer -> discoverer.getEnergy() == 0)
                .count();
        inspectedSpots++;
        return String.format(INSPECT_SPOT, spotName, tiredDiscoverers);
    }

    @Override
    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(FINAL_SPOT_INSPECT, inspectedSpots))
                .append(System.lineSeparator())
                .append(FINAL_DISCOVERER_INFO)
                .append(System.lineSeparator());
        for (Discoverer discoverer : discovererRepository.getCollection()) {
            sb.append(String.format(FINAL_DISCOVERER_NAME, discoverer.getName()))
                    .append(System.lineSeparator())
                    .append(String.format(FINAL_DISCOVERER_ENERGY, discoverer.getEnergy()))
                    .append(System.lineSeparator());
            if (discoverer.getMuseum().getExhibits().isEmpty()) {
                sb.append(String.format(FINAL_DISCOVERER_MUSEUM_EXHIBITS, "None")).append(System.lineSeparator());
            } else {
                String museumExhibitsText = String.join(FINAL_DISCOVERER_MUSEUM_EXHIBITS_DELIMITER, discoverer.getMuseum().getExhibits());
                sb.append(String.format(FINAL_DISCOVERER_MUSEUM_EXHIBITS, museumExhibitsText)).append(System.lineSeparator());
            }
        }
        return sb.toString().trim();
    }
}
