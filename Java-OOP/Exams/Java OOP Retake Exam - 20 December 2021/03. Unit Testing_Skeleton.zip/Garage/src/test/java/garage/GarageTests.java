package garage;

import org.junit.Assert;
import org.junit.Test;

public class GarageTests {
    //TODO: Test Garage class
}